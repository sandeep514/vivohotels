<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use App\Http\Requests\AddProperty;

class PropertyController extends Controller
{
    public function index()
    {
        return view('admin.property.addProperty');
    }
    public function create(AddProperty $request)
    {
        $createProperty = AddProperty::create([
            'title'             => $request->title,
            'description'       => $request->description,
            'address'           => $request->address,
            'mobile'            => $request->mobile,
            'email'             => $request->email,
            'propertyType'      => $request->propertyType,
            'propertyRaiting'   => $request->propertyRaiting,
            'propertyCategory'  => $request->propertyCategory,
            'regular_price'     => $request->regular_price,
            'offer_price'       => $request->offer_price,
            'timmingFrom'       => $request->timmingFrom,
            'timmingTo'         => $request->timmingTo,
            'availability'      => $request->availability
        ]);

        if( $createProperty ){
            if($request->hasFile('propertyImage')) {
                $image       = $request->file('propertyImage');
                $filename    = $image->getClientOriginalName();
            
                $image_resize = Image::make($image->getRealPath());              
                $image_resize->resize(300, 300);
                $image_resize->save(public_path('property/'.$propertyId.'/'.$filename));
                AddProperty::where('id' , $createProperty->id)->update([ 'propertyImage' => $filename ]);
            }
            
            if($request->hasFile('otherImages')) {
                $otherImg = [];
                foreach( $request->file('otherImages') as $k => $v){
                    $image       = $request->file('otherImages');
                    $filename    = $image->getClientOriginalName();
                
                    $image_resize = Image::make($image->getRealPath());              
                    $image_resize->resize(300, 300);
                    $image_resize->save(public_path('property/'.$propertyId.'/'.$filename));        
                    $otherImg[] = $filename;
                }
                $encodedOtherImages  = json_encode($otherImg);
                AddProperty::where('id' , $createProperty->id)->update([ 'otherImages' => $encodedOtherImages ]);
            }
        }
        


        






        dd($request->all());
    }
}