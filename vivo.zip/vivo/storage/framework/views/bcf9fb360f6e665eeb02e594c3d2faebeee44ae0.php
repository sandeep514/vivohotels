<head>
    <title> VIVO Hotels </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <style id="" media="all">/* vietnamese */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-display: swap;
            src: local('Nunito Sans ExtraLight'), local('NunitoSans-ExtraLight'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc9yAs5iU1EQVg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }
        /* latin-ext */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-display: swap;
            src: local('Nunito Sans ExtraLight'), local('NunitoSans-ExtraLight'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc9yAs5jU1EQVg.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }
        /* latin */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 200;
            font-display: swap;
            src: local('Nunito Sans ExtraLight'), local('NunitoSans-ExtraLight'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc9yAs5tU1E.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
        /* vietnamese */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: local('Nunito Sans Light'), local('NunitoSans-Light'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc8WAc5iU1EQVg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }
        /* latin-ext */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: local('Nunito Sans Light'), local('NunitoSans-Light'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc8WAc5jU1EQVg.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }
        /* latin */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: local('Nunito Sans Light'), local('NunitoSans-Light'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc8WAc5tU1E.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
        /* vietnamese */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: local('Nunito Sans Regular'), local('NunitoSans-Regular'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8cceyI9tScg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }
        /* latin-ext */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: local('Nunito Sans Regular'), local('NunitoSans-Regular'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8ccezI9tScg.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }
        /* latin */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: local('Nunito Sans Regular'), local('NunitoSans-Regular'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8cce9I9s.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
        /* vietnamese */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-display: swap;
            src: local('Nunito Sans SemiBold'), local('NunitoSans-SemiBold'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc9iB85iU1EQVg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }
        /* latin-ext */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-display: swap;
            src: local('Nunito Sans SemiBold'), local('NunitoSans-SemiBold'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc9iB85jU1EQVg.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }
        /* latin */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 600;
            font-display: swap;
            src: local('Nunito Sans SemiBold'), local('NunitoSans-SemiBold'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc9iB85tU1E.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
        /* vietnamese */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: local('Nunito Sans Bold'), local('NunitoSans-Bold'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc8GBs5iU1EQVg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }
        /* latin-ext */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: local('Nunito Sans Bold'), local('NunitoSans-Bold'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc8GBs5jU1EQVg.woff2) format('woff2');
            unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }
        /* latin */
        @font-face {
            font-family: 'Nunito Sans';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: local('Nunito Sans Bold'), local('NunitoSans-Bold'), url(https://colorlib.com/fonts.gstatic.com/s/nunitosans/v6/pe03MImSLYBIv1o4X1M8cc8GBs5tU1E.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
        .toast{
            background: white;
            position: absolute;
            z-index: 9999;
            right: 100px;
            top: 20px;
        }
    </style>

    <link rel="stylesheet" href="<?php echo e(asset('front/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/animate.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/jquery.timepicker.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('front/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>">
</head>
<?php /**PATH C:\xampp7.4\htdocs\vivo\resources\views/front/components/header.blade.php ENDPATH**/ ?>