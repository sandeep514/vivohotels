
<script src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.animateNumber.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/scrollax.min.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false"></script>
<script src="<?php echo e(asset('front/js/google-map.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/main.js')); ?>"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());

	gtag('config', 'UA-23581568-13');

$(document).ready(function(){
	$('.activeToast').toast({ delay: 4000 });
	$('.activeToast').toast('show');
});

$(document).ready(function(){
	$('.errorToast').toast({ delay: 4000 });
	$('.errorToast').toast('show');
});
</script><?php /**PATH C:\xampp7.4\htdocs\vivo\resources\views/front/components/script.blade.php ENDPATH**/ ?>