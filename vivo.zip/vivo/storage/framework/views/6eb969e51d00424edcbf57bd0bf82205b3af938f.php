
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-md-12 ">
                            <div class="card">
                                
                                <div class="card-block">
                                    <h4 class="sub-title">Add New Property</h4>

                                    <form method="POST" action="<?php echo e(route('admin.submit.new.property')); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Title</label>
                                            <div class="col-sm-10">
                                                <input type="text" value="title" name="title" class="form-control" placeholder="Title">
                                                    <?php if($errors->has('title')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Description</label>
                                            <div class="col-sm-10">
                                                <textarea rows="5" cols="5" class="form-control" value="description" name="description" placeholder="Description"></textarea>
                                                    <?php if($errors->has('description')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Address</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" value="address" name="address" placeholder="Enter Address">
                                                    <?php if($errors->has('address')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Mobile</label>
                                            <div class="col-sm-10">
                                                <input type="number" class="form-control" value="9653338547" name="mobile" placeholder="Enter mobile number">
                                                    <?php if($errors->has('mobile')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('mobile')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Email</label>
                                            <div class="col-sm-10">
                                                <input type="email" class="form-control" value="sandeep@gmail.com" name="email" placeholder="Enter email">
                                                    <?php if($errors->has('email')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>
                                       
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Property Type</label>
                                            <div class="col-sm-10">
                                                <select class="form-control" name="propertyType">
                                                    <option value="opt1">Select One Value Only</option>
                                                    <option value="opt2" selected>Type 2</option>
                                                </select>
                                                    <?php if($errors->has('propertyType')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('propertyType')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Property Raiting</label>
                                            <div class="col-sm-10">
                                                <select class="form-control" name="propertyRaiting">
                                                    <option value="opt1" >Select One Value Only</option>
                                                    <option value="opt2" selected>Type 2</option>
                                                </select>
                                                    <?php if($errors->has('propertyRaiting')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('propertyRaiting')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Property Category</label>
                                            <div class="col-sm-10">
                                                <select class="form-control" name="propertyCategory">
                                                    <option value="opt1">Select One Value Only</option>
                                                    <option value="opt2" selected>Type 2</option>
                                                </select>
                                                    <?php if($errors->has('propertyCategory')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('propertyCategory')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Regular Price</label>
                                            <div class="col-sm-10">
                                                <input type="number" value="200" class="form-control" name="regular_price" placeholder="Price before Offer">
                                                    <?php if($errors->has('regular_price')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('regular_price')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Offer Price</label>
                                            <div class="col-sm-10">
                                                <input type="number" value="160" class="form-control" name="offer_price" placeholder="Price after Offer">
                                                    <?php if($errors->has('offer_price')): ?>
                                                        <span class="error">
                                                            <strong><?php echo e($errors->first('offer_price')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Property Image</label>
                                            <div class="col-sm-10">
                                                <input type="file" class="form-control" name="propertyImage">
                                                <?php if($errors->has('propertyImage')): ?>
                                                    <span class="error">
                                                        <strong><?php echo e($errors->first('propertyImage')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Other Image</label>
                                            <div class="col-sm-10">
                                                <input type="file" multiple class="form-control" name="otherImages">
                                                <?php if($errors->has('otherImages')): ?>
                                                    <span class="error">
                                                        <strong><?php echo e($errors->first('otherImages')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Timming From</label>
                                            <div class="col-sm-10">
                                                <input type="time" class="form-control" name="timmingFrom">
                                                <?php if($errors->has('timmingFrom')): ?>
                                                    <span class="error">
                                                        <strong><?php echo e($errors->first('timmingFrom')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Timming To</label>
                                            <div class="col-sm-10">
                                                <input type="time" class="form-control" name="timmingTo">
                                                <?php if($errors->has('timmingTo')): ?>
                                                    <span class="error">
                                                        <strong><?php echo e($errors->first('timmingTo')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Availability</label>
                                            <div class="col-sm-1">
                                                <label class="switch">
                                                    <input type="checkbox" name="availability" checked>
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                        </div>

                                        <input type="submit" class="btn btn-primary" value="Add Property">
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\vivo\resources\views/admin/property/addProperty.blade.php ENDPATH**/ ?>